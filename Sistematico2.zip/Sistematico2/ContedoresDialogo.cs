﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistematico2
{
    internal class ContedoresDialogo
    { 
        public static string Nombre { get; set; }
        public static string Apellido { get; set; }
        public static string Carnet { get; set; }
        public static string Carrera { get; set; }
        public static int Telefono { get; set; }
        public static string Pais { get; set; }
    }
}
