﻿namespace Sistematico2
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMenuBarra = new System.Windows.Forms.Button();
            this.btnContenedores = new System.Windows.Forms.Button();
            this.btnValidacionCampos = new System.Windows.Forms.Button();
            this.btnRangoDef = new System.Windows.Forms.Button();
            this.btnCajaDailogos = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMenuBarra
            // 
            this.btnMenuBarra.Location = new System.Drawing.Point(29, 66);
            this.btnMenuBarra.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnMenuBarra.Name = "btnMenuBarra";
            this.btnMenuBarra.Size = new System.Drawing.Size(117, 34);
            this.btnMenuBarra.TabIndex = 0;
            this.btnMenuBarra.Text = "Menu y Barra";
            this.btnMenuBarra.UseVisualStyleBackColor = true;
            this.btnMenuBarra.Click += new System.EventHandler(this.btnMenuBarra_Click);
            // 
            // btnContenedores
            // 
            this.btnContenedores.Location = new System.Drawing.Point(172, 66);
            this.btnContenedores.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnContenedores.Name = "btnContenedores";
            this.btnContenedores.Size = new System.Drawing.Size(118, 34);
            this.btnContenedores.TabIndex = 1;
            this.btnContenedores.Text = "Contenedores";
            this.btnContenedores.UseVisualStyleBackColor = true;
            this.btnContenedores.Click += new System.EventHandler(this.btnContenedores_Click);
            // 
            // btnValidacionCampos
            // 
            this.btnValidacionCampos.Location = new System.Drawing.Point(318, 66);
            this.btnValidacionCampos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnValidacionCampos.Name = "btnValidacionCampos";
            this.btnValidacionCampos.Size = new System.Drawing.Size(146, 34);
            this.btnValidacionCampos.TabIndex = 2;
            this.btnValidacionCampos.Text = "Cajas de Dialogos";
            this.btnValidacionCampos.UseVisualStyleBackColor = true;
            this.btnValidacionCampos.Click += new System.EventHandler(this.btnValidacionCampos_Click);
            // 
            // btnRangoDef
            // 
            this.btnRangoDef.Location = new System.Drawing.Point(486, 66);
            this.btnRangoDef.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRangoDef.Name = "btnRangoDef";
            this.btnRangoDef.Size = new System.Drawing.Size(141, 34);
            this.btnRangoDef.TabIndex = 3;
            this.btnRangoDef.Text = "Rango Definidido";
            this.btnRangoDef.UseVisualStyleBackColor = true;
            this.btnRangoDef.Click += new System.EventHandler(this.btnRangoDef_Click);
            // 
            // btnCajaDailogos
            // 
            this.btnCajaDailogos.Location = new System.Drawing.Point(661, 66);
            this.btnCajaDailogos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCajaDailogos.Name = "btnCajaDailogos";
            this.btnCajaDailogos.Size = new System.Drawing.Size(134, 34);
            this.btnCajaDailogos.TabIndex = 4;
            this.btnCajaDailogos.Text = "Validacion de Campos";
            this.btnCajaDailogos.UseVisualStyleBackColor = true;
            this.btnCajaDailogos.Click += new System.EventHandler(this.btnCajaDailogos_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(686, 140);
            this.btnSalir.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(130, 37);
            this.btnSalir.TabIndex = 5;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(828, 188);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.btnCajaDailogos);
            this.Controls.Add(this.btnRangoDef);
            this.Controls.Add(this.btnValidacionCampos);
            this.Controls.Add(this.btnContenedores);
            this.Controls.Add(this.btnMenuBarra);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Menu";
            this.Text = "Menu";
            this.ResumeLayout(false);

        }

        #endregion

        private Button btnMenuBarra;
        private Button btnContenedores;
        private Button btnValidacionCampos;
        private Button btnRangoDef;
        private Button btnCajaDailogos;
        private Button btnSalir;
    }
}