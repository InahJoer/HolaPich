﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistematico2
{
    internal class BarraProgreso
    {
        public int PorcentajeCompleto { get; set; }

    }
}
